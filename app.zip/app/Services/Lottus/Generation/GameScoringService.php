<?php

namespace App\Services\Lottus\Generation;

use App\Models\LotofacilConcurso;

class GameScoringService
{
    public function rank(
        array $candidates,
        array $frequencyContext,
        array $delayContext,
        array $correlationContext,
        array $structureContext,
        LotofacilConcurso $concursoBase
    ): array {
        $ultimoConcurso = $this->extractNumbers($concursoBase);
        $ranked = [];

        foreach ($candidates as $candidate) {
            $game = $candidate['dezenas'] ?? $candidate;
            $profile = $candidate['profile'] ?? 'balanced';
            $cycleMissing = $candidate['cycle_missing'] ?? [];

            sort($game);

            $frequencyScore = $this->sumMetric($game, $frequencyContext['scores'] ?? []);
            $delayScore = $this->sumMetric($game, $delayContext['scores'] ?? []);
            $correlationScore = $this->pairMetric($game, $correlationContext['pair_scores'] ?? []);

            $repeatCount = count(array_intersect($game, $ultimoConcurso));
            $cycleHit = count(array_intersect($game, $cycleMissing));

            $oddCount = count(array_filter($game, fn ($n) => $n % 2 !== 0));
            $evenCount = 15 - $oddCount;
            $sum = array_sum($game);
            $lineDistribution = $this->lineDistribution($game);
            $longestSequence = $this->longestSequence($game);
            $frameCount = $this->frameCount($game);
            $middleCount = 15 - $frameCount;
            $clusterStrength = $this->clusterStrength($game);
            $quadrantDistribution = $this->quadrantDistribution($game);

            $statScore =
                ($frequencyScore * 0.22) +
                ($delayScore * 0.20) +
                ($correlationScore * 0.18);

            $repeatQuality = $this->repeatQuality($repeatCount);
            $cycleQuality = $this->cycleQuality($cycleHit, $cycleMissing);
            $sumQuality = $this->sumQuality($sum);
            $parityQuality = $this->parityQuality($oddCount, $evenCount);
            $sequenceQuality = $this->sequenceQuality($longestSequence);
            $lineQuality = $this->lineQuality($lineDistribution);
            $frameQuality = $this->frameQuality($frameCount, $middleCount);
            $clusterQuality = $this->clusterQuality($clusterStrength);
            $quadrantQuality = $this->quadrantQuality($quadrantDistribution);

            $extremeScore =
                ($repeatQuality * 6.00) +
                ($cycleQuality * 3.20) +
                ($clusterQuality * 2.60) +
                ($sequenceQuality * 2.10) +
                ($frameQuality * 1.60) +
                ($sumQuality * 1.40) +
                ($parityQuality * 1.10) +
                ($lineQuality * 0.90) +
                ($quadrantQuality * 0.80);

            if ($repeatCount >= 9 && $repeatCount <= 10 && $cycleHit >= 2) {
                $extremeScore += 4.0;
            }

            if ($repeatCount >= 8 && $repeatCount <= 11 && $clusterStrength >= 4.0) {
                $extremeScore += 2.8;
            }

            if ($longestSequence >= 3 && $longestSequence <= 5) {
                $extremeScore += 1.5;
            }

            if ($frameCount >= 8 && $frameCount <= 11) {
                $extremeScore += 1.3;
            }

            if ($sum >= 175 && $sum <= 210) {
                $extremeScore += 1.2;
            }

            $profileBoost = match ($profile) {
                'aggressive', 'explosive' => 1.08,
                'balanced' => 1.00,
                default => 1.03,
            };

            $score = ($extremeScore + ($statScore * 0.35)) * $profileBoost;

            $ranked[] = [
                'dezenas' => $game,
                'profile' => $profile,
                'score' => round($score, 6),
                'extreme_score' => round($extremeScore, 6),
                'stat_score' => round($statScore, 6),
                'pares' => $evenCount,
                'impares' => $oddCount,
                'soma' => $sum,
                'repetidas_ultimo_concurso' => $repeatCount,
                'cycle_hits' => $cycleHit,
                'analise' => [
                    'profile' => $profile,
                    'repeat' => $repeatCount,
                    'cycle_hits' => $cycleHit,
                    'pares' => $evenCount,
                    'impares' => $oddCount,
                    'soma' => $sum,
                    'sequencia_maxima' => $longestSequence,
                    'linhas' => $lineDistribution,
                    'moldura' => $frameCount,
                    'miolo' => $middleCount,
                    'cluster_strength' => round($clusterStrength, 4),
                    'quadrantes' => $quadrantDistribution,
                    'repeat_quality' => round($repeatQuality, 4),
                    'cycle_quality' => round($cycleQuality, 4),
                    'sum_quality' => round($sumQuality, 4),
                    'parity_quality' => round($parityQuality, 4),
                    'sequence_quality' => round($sequenceQuality, 4),
                    'line_quality' => round($lineQuality, 4),
                    'frame_quality' => round($frameQuality, 4),
                    'cluster_quality' => round($clusterQuality, 4),
                    'quadrant_quality' => round($quadrantQuality, 4),
                ],
            ];
        }

        usort($ranked, fn ($a, $b) => $b['score'] <=> $a['score']);

        return $ranked;
    }

    protected function sumMetric(array $game, array $scores): float
    {
        $total = 0.0;

        foreach ($game as $number) {
            $total += (float) ($scores[$number] ?? 0.0);
        }

        return $total;
    }

    protected function pairMetric(array $game, array $pairScores): float
    {
        $total = 0.0;
        $count = 0;

        for ($i = 0; $i < count($game); $i++) {
            for ($j = $i + 1; $j < count($game); $j++) {
                $a = $game[$i];
                $b = $game[$j];

                $total += (float) ($pairScores[$a][$b] ?? $pairScores[$b][$a] ?? 0.0);
                $count++;
            }
        }

        return $count ? ($total / $count) : 0.0;
    }

    protected function repeatQuality(int $repeatCount): float
    {
        return match (true) {
            $repeatCount >= 9 && $repeatCount <= 10 => 1.00,
            $repeatCount === 8 || $repeatCount === 11 => 0.78,
            $repeatCount === 7 || $repeatCount === 12 => 0.42,
            default => 0.12,
        };
    }

    protected function cycleQuality(int $cycleHit, array $cycleMissing): float
    {
        if (empty($cycleMissing)) {
            return 0.45;
        }

        return match (true) {
            $cycleHit >= 4 => 1.00,
            $cycleHit === 3 => 0.82,
            $cycleHit === 2 => 0.66,
            $cycleHit === 1 => 0.35,
            default => 0.10,
        };
    }

    protected function sumQuality(int $sum): float
    {
        return match (true) {
            $sum >= 175 && $sum <= 210 => 1.00,
            $sum >= 166 && $sum <= 220 => 0.72,
            default => 0.20,
        };
    }

    protected function parityQuality(int $oddCount, int $evenCount): float
    {
        return match (true) {
            ($oddCount === 7 && $evenCount === 8) || ($oddCount === 8 && $evenCount === 7) => 1.00,
            ($oddCount === 6 && $evenCount === 9) || ($oddCount === 9 && $evenCount === 6) => 0.72,
            default => 0.25,
        };
    }

    protected function sequenceQuality(int $longestSequence): float
    {
        return match (true) {
            $longestSequence >= 3 && $longestSequence <= 5 => 1.00,
            $longestSequence === 2 || $longestSequence === 6 => 0.58,
            default => 0.18,
        };
    }

    protected function lineQuality(array $lineDistribution): float
    {
        $maxLine = max($lineDistribution);
        $minLine = min($lineDistribution);

        return match (true) {
            $maxLine <= 4 && $minLine >= 2 => 1.00,
            $maxLine <= 5 && $minLine >= 1 => 0.65,
            default => 0.22,
        };
    }

    protected function frameQuality(int $frameCount, int $middleCount): float
    {
        return match (true) {
            $frameCount >= 8 && $frameCount <= 11 => 1.00,
            $frameCount === 7 || $frameCount === 12 => 0.62,
            default => 0.20,
        };
    }

    protected function clusterQuality(float $clusterStrength): float
    {
        return match (true) {
            $clusterStrength >= 4.5 => 1.00,
            $clusterStrength >= 3.5 => 0.76,
            $clusterStrength >= 2.8 => 0.48,
            default => 0.20,
        };
    }

    protected function quadrantQuality(array $quadrantDistribution): float
    {
        $max = max($quadrantDistribution);
        $min = min($quadrantDistribution);

        return match (true) {
            $max <= 5 && $min >= 2 => 1.00,
            $max <= 6 && $min >= 1 => 0.66,
            default => 0.24,
        };
    }

    protected function lineDistribution(array $game): array
    {
        $lines = [0, 0, 0, 0, 0];

        foreach ($game as $number) {
            $index = (int) floor(($number - 1) / 5);
            $lines[$index]++;
        }

        return $lines;
    }

    protected function longestSequence(array $game): int
    {
        if (empty($game)) {
            return 0;
        }

        $longest = 1;
        $current = 1;

        for ($i = 1; $i < count($game); $i++) {
            if ($game[$i] === $game[$i - 1] + 1) {
                $current++;
                $longest = max($longest, $current);
            } else {
                $current = 1;
            }
        }

        return $longest;
    }

    protected function frameCount(array $game): int
    {
        $frameNumbers = [
            1, 2, 3, 4, 5,
            6, 10,
            11, 15,
            16, 20,
            21, 22, 23, 24, 25,
        ];

        return count(array_intersect($game, $frameNumbers));
    }

    protected function clusterStrength(array $game): float
    {
        $clusters = 0;
        $run = 1;

        for ($i = 1; $i < count($game); $i++) {
            if ($game[$i] <= $game[$i - 1] + 2) {
                $run++;
            } else {
                if ($run >= 2) {
                    $clusters += $run;
                }
                $run = 1;
            }
        }

        if ($run >= 2) {
            $clusters += $run;
        }

        return $clusters / 15;
    }

    protected function quadrantDistribution(array $game): array
    {
        $quadrants = [0, 0, 0, 0];

        foreach ($game as $number) {
            if ($number >= 1 && $number <= 7) {
                $quadrants[0]++;
            } elseif ($number >= 8 && $number <= 13) {
                $quadrants[1]++;
            } elseif ($number >= 14 && $number <= 19) {
                $quadrants[2]++;
            } else {
                $quadrants[3]++;
            }
        }

        return $quadrants;
    }

    protected function extractNumbers(LotofacilConcurso $concurso): array
    {
        $numbers = [];

        for ($i = 1; $i <= 15; $i++) {
            $numbers[] = (int) $concurso->{'bola' . $i};
        }

        sort($numbers);

        return $numbers;
    }
}