<?php

namespace App\Services\Lottus\Generation;

class PortfolioOptimizerService
{
    public function optimize(array $rankedGames, int $quantidade): array
    {
        if ($quantidade <= 0 || empty($rankedGames)) {
            return [];
        }

        $pool = array_values($rankedGames);

        usort($pool, function ($a, $b) {
            return $this->huntValue($b) <=> $this->huntValue($a);
        });

        $selected = [];

        $lockedCandidates = $this->extractRawPriorityLockedCandidates($pool);

        foreach ($lockedCandidates as $candidate) {
            if (count($selected) >= $quantidade) {
                break;
            }

            if ($this->alreadySelected($candidate, $selected)) {
                continue;
            }

            $selected[] = $candidate;
        }

        $eliteCandidates = $this->extractEliteCandidates($pool);

        foreach ($eliteCandidates as $candidate) {
            if (count($selected) >= $quantidade) {
                break;
            }

            if ($this->alreadySelected($candidate, $selected)) {
                continue;
            }

            $selected[] = $candidate;
        }

        foreach ($pool as $candidate) {
            if (count($selected) >= $quantidade) {
                break;
            }

            if ($this->alreadySelected($candidate, $selected)) {
                continue;
            }

            if ($this->isHardClone($candidate, $selected)) {
                continue;
            }

            $selected[] = $candidate;
        }

        if (count($selected) < $quantidade) {
            foreach ($rankedGames as $candidate) {
                if (count($selected) >= $quantidade) {
                    break;
                }

                if ($this->alreadySelected($candidate, $selected)) {
                    continue;
                }

                $selected[] = $candidate;
            }
        }

        return array_slice($selected, 0, $quantidade);
    }

    protected function extractRawPriorityLockedCandidates(array $pool): array
    {
        if (empty($pool)) {
            return [];
        }

        $locked = [];

        $extremeScores = array_map(
            fn ($candidate) => (float) ($candidate['extreme_score'] ?? 0.0),
            $pool
        );

        rsort($extremeScores);

        $topExtreme = $extremeScores[0] ?? 0.0;
        $thirdExtreme = $extremeScores[min(2, count($extremeScores) - 1)] ?? 0.0;

        foreach ($pool as $candidate) {
            $extremeScore = (float) ($candidate['extreme_score'] ?? 0.0);
            $score = (float) ($candidate['score'] ?? 0.0);
            $repeatCount = (int) ($candidate['repetidas_ultimo_concurso'] ?? 0);
            $cycleHits = (int) ($candidate['cycle_hits'] ?? 0);
            $sum = (int) ($candidate['soma'] ?? 0);
            $oddCount = (int) ($candidate['impares'] ?? 0);
            $sequence = (int) ($candidate['analise']['sequencia_maxima'] ?? 0);

            $isMonsterCandidate = false;

            if (
                $extremeScore >= ($topExtreme * 0.94) &&
                $repeatCount >= 8 &&
                $repeatCount <= 11 &&
                $cycleHits >= 2 &&
                $sum >= 170 &&
                $sum <= 215 &&
                $oddCount >= 6 &&
                $oddCount <= 9
            ) {
                $isMonsterCandidate = true;
            }

            if (
                $extremeScore >= $thirdExtreme &&
                $repeatCount >= 9 &&
                $cycleHits >= 2 &&
                $sequence >= 3 &&
                $sequence <= 5
            ) {
                $isMonsterCandidate = true;
            }

            if (
                $score > 0 &&
                $extremeScore >= ($topExtreme * 0.90) &&
                $repeatCount >= 8 &&
                $cycleHits >= 3
            ) {
                $isMonsterCandidate = true;
            }

            if ($isMonsterCandidate) {
                $locked[] = $candidate;
            }
        }

        usort($locked, function ($a, $b) {
            return $this->priorityLockValue($b) <=> $this->priorityLockValue($a);
        });

        return $locked;
    }

    protected function priorityLockValue(array $candidate): float
    {
        $extremeScore = (float) ($candidate['extreme_score'] ?? 0.0);
        $score = (float) ($candidate['score'] ?? 0.0);
        $repeatCount = (int) ($candidate['repetidas_ultimo_concurso'] ?? 0);
        $cycleHits = (int) ($candidate['cycle_hits'] ?? 0);
        $sum = (int) ($candidate['soma'] ?? 0);
        $oddCount = (int) ($candidate['impares'] ?? 0);
        $sequence = (int) ($candidate['analise']['sequencia_maxima'] ?? 0);

        $value = 0.0;

        $value += $extremeScore * 10;
        $value += $score * 0.03;

        if ($repeatCount >= 9 && $repeatCount <= 10) {
            $value += 35;
        }

        if ($cycleHits >= 3) {
            $value += 25;
        } elseif ($cycleHits === 2) {
            $value += 12;
        }

        if ($sum >= 175 && $sum <= 210) {
            $value += 10;
        }

        if ($oddCount === 7 || $oddCount === 8) {
            $value += 8;
        }

        if ($sequence >= 3 && $sequence <= 5) {
            $value += 10;
        }

        return $value;
    }

    protected function extractEliteCandidates(array $pool): array
    {
        if (empty($pool)) {
            return [];
        }

        $elite = [];

        $extremeScores = array_map(
            fn ($candidate) => (float) ($candidate['extreme_score'] ?? 0.0),
            $pool
        );

        $mean = array_sum($extremeScores) / count($extremeScores);

        $variance = 0.0;

        foreach ($extremeScores as $score) {
            $variance += pow($score - $mean, 2);
        }

        $stdDev = sqrt($variance / max(1, count($extremeScores)));
        $threshold = $mean + ($stdDev * 0.60);

        foreach ($pool as $candidate) {
            $extremeScore = (float) ($candidate['extreme_score'] ?? 0.0);
            $repeatCount = (int) ($candidate['repetidas_ultimo_concurso'] ?? 0);
            $cycleHits = (int) ($candidate['cycle_hits'] ?? 0);

            if (
                $extremeScore >= $threshold &&
                $repeatCount >= 8 &&
                $cycleHits >= 2
            ) {
                $elite[] = $candidate;
            }
        }

        usort($elite, function ($a, $b) {
            return $this->huntValue($b) <=> $this->huntValue($a);
        });

        return $elite;
    }

    protected function huntValue(array $candidate): float
    {
        $extremeScore = (float) ($candidate['extreme_score'] ?? 0.0);
        $score = (float) ($candidate['score'] ?? 0.0);
        $repeatCount = (int) ($candidate['repetidas_ultimo_concurso'] ?? 0);
        $cycleHits = (int) ($candidate['cycle_hits'] ?? 0);
        $sum = (int) ($candidate['soma'] ?? 0);
        $oddCount = (int) ($candidate['impares'] ?? 0);
        $sequence = (int) ($candidate['analise']['sequencia_maxima'] ?? 0);

        $value = ($extremeScore * 6.5) + ($score * 0.05);

        if ($repeatCount >= 9 && $repeatCount <= 10) {
            $value += 20;
        }

        if ($cycleHits >= 2) {
            $value += 12;
        }

        if ($sum >= 175 && $sum <= 210) {
            $value += 6;
        }

        if ($oddCount === 7 || $oddCount === 8) {
            $value += 5;
        }

        if ($sequence >= 3 && $sequence <= 5) {
            $value += 4;
        }

        return $value;
    }

    protected function isHardClone(array $candidate, array $selected): bool
    {
        foreach ($selected as $game) {
            $intersection = count(array_intersect(
                $candidate['dezenas'] ?? [],
                $game['dezenas'] ?? []
            ));

            if ($intersection >= 14) {
                return true;
            }
        }

        return false;
    }

    protected function alreadySelected(array $candidate, array $selected): bool
    {
        $candidateKey = $this->candidateKey($candidate);

        foreach ($selected as $game) {
            if ($candidateKey === $this->candidateKey($game)) {
                return true;
            }
        }

        return false;
    }

    protected function candidateKey(array $candidate): string
    {
        return implode('-', $candidate['dezenas'] ?? []);
    }
}